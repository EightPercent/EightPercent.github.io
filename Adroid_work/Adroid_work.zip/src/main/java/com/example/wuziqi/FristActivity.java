package com.example.wuziqi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * Created by ydkf051 on 2017/12/18.
 */

public class FristActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fristactivity);
    }
    public void start(View v){
        Intent intent=new Intent(FristActivity.this,MainActivity.class);
        startActivity(intent);
    }
    public void startPE(View v){
        Intent intent2=new Intent(FristActivity.this,MainActivity2.class);
        startActivity(intent2);
    }
    public void exit(View v){
        finish();
    }
}
