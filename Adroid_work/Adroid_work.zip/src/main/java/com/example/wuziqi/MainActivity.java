package com.example.wuziqi;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;

public class MainActivity extends Activity {
	Chronometer chronometer;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		chronometer=(Chronometer)findViewById(R.id.cr);
		chronometer.setBase(SystemClock.elapsedRealtime());
		chronometer.setFormat("%s");
		chronometer.start();
	}
	public void restart (View v){
		onCreate(null);
		chronometer.setBase(SystemClock.elapsedRealtime());
		chronometer.setFormat("%s");
		chronometer.start();
	}
	public void comeback (View v){
		finish();
	}
}
