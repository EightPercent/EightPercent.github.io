package com.example.wuziqi;


import android.os.Bundle;
import android.app.Activity;
import android.view.View;


public class MainActivity2 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
    }
    public void restart (View v){
        onCreate(null);
    }
    public void comeback (View v){
        finish();
    }
}
